﻿namespace EasyLearn.Models.Entities;

public class EmailSender
{
    public string ReceiverName { get; set; }
    public string ReceiverEmail { get; set; }
    public string Message { get; set; }
    public string Subject { get; set; }
    public string File { get; set; }
    public string FIleName { get; set; }
}

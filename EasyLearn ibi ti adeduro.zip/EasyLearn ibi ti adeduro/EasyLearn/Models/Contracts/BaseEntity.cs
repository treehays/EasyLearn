﻿namespace EasyLearn.Models.Contracts
{
    public abstract class BaseEntity
    {
        public string Id { get; set; }

    }
}

﻿namespace EasyLearn.Models.Enums
{
    public enum PaymentMethods
    {
        PayStack = 1,
        BankTransfer,

    }
}

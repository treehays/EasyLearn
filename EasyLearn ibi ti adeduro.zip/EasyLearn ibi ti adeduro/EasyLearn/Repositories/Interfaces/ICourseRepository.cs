﻿using EasyLearn.Models.Entities;

namespace EasyLearn.Repositories.Interfaces;

public interface ICourseRepository : IRepository<Course>
{
    //Task<Course> SearchCourse(string word);
}
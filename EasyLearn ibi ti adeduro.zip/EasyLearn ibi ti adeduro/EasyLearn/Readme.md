 Layout = "~/Views/Shared/Layouts/_layout_light_sidebar.cshtml"; // this is the origianl sidebar layout (complre)





#C:\Users\Abdul\source\repos\EasyLearn\EasyLearn\Views\Shared\Layouts\_layout_light_sidebar.cshtml  //this is the original side bar layout (( <partial name="~/Views/Shared/_sidebar.cshtml"/>))


                    <partial name="~/Views/Shared/_page_title.cshtml"/>// this is used for thr breadcrumb

                    
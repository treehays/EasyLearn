﻿namespace EasyLearn.Models.Enums
{
    public enum EnrolmentStatus
    {
        Enrolled = 1,
        NotEnrolled
    }
}

﻿namespace EasyLearn.Models.Enums;

public enum Gender
{
    Male =1,
    Female
}
﻿namespace EasyLearn.Models.Enums
{
    public enum PaymentStatus
    {
        IsPaid = 1,
        NotPaid
    }
}

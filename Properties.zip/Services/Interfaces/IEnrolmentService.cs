﻿namespace EasyLearn.Services.Interfaces
{
    public interface IEnrolmentService
    {
    }
}

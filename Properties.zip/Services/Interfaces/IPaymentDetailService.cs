﻿namespace EasyLearn.Services.Interfaces
{
    public interface IPaymentDetailService
    {
    }
}

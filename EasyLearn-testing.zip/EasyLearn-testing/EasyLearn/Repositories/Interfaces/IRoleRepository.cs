﻿using EasyLearn.Models.Entities;

namespace EasyLearn.Repositories.Interfaces;

public interface IRoleRepository : IRepository<Role>
{
    
}
﻿using EasyLearn.Models.Entities;

namespace EasyLearn.Repositories.Interfaces;

public interface ICourseReviewRepository : IRepository<CourseReview>
{
    
}
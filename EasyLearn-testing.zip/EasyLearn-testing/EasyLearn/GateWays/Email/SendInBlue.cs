﻿namespace EasyLearn.GateWays.Email
{
    public class SendInBlue
    {
    }
}

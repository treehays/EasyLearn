﻿namespace EasyLearn.Services.Interfaces
{
    public interface IPaymentService
    {
    }
}

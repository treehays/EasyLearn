﻿namespace EasyLearn.Services.Interfaces
{
    public class ICourseReviewService
    {
    }
}

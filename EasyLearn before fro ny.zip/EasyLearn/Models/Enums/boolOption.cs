﻿namespace EasyLearn.Models.Enums;

public enum boolOption
{
    IsFalse,
    IsTrue
}
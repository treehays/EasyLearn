﻿namespace EasyLearn.Models.Enums
{
    public enum CompletionStatus
    {
        Completed = 1,
        NotCompleted
    }
}

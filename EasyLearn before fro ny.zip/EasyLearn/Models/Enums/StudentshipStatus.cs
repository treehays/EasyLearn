﻿namespace EasyLearn.Models.Enums;

public enum StudentshipStatus
{
    Student = 1,
    Graduate
}
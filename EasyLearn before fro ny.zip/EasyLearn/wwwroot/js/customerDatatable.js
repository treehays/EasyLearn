﻿$(document).ready(function () {
    $('#customerDatatable').dataTable({
    });
});

﻿using EasyLearn.Models.Entities;

namespace EasyLearn.Repositories.Interfaces;

public interface IModuleRepository : IRepository<Module>
{
    Task<int> GetLastElement();
}
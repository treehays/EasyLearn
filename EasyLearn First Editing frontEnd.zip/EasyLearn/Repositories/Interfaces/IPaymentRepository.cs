﻿using EasyLearn.Models.Entities;

namespace EasyLearn.Repositories.Interfaces;

public interface IPaymentRepository : IRepository<Payment>
{
    
}
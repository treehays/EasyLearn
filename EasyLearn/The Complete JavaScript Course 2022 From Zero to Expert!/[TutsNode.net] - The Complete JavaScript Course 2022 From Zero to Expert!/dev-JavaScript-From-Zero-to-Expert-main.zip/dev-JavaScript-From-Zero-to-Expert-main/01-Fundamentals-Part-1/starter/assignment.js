/* ASSIGNMENT 1
let country = 'Argentina';
let continent = 'South America';
let population = '43 millions';

console.log(country);
console.log(continent);
console.log(population);
*/
